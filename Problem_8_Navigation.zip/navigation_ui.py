import streamlit as st
import time
import pandas as pd
from Problem_8_Navigation.bfs import bfs
from Problem_8_Navigation.dfs import dfs

def run_navigation():
    st.subheader("🧭 Smart Navigation System")

    graph = {
        "A": ["B", "C"],
        "B": ["D", "E"],
        "C": ["D"],
        "D": ["F"],
        "E": ["F"],
        "F": []
    }

    start = st.text_input("Start Node", "A")
    goal = st.text_input("Goal Node", "F")

    if st.button("🚀 Find Path"):

        t1 = time.time()
        bfs_path = bfs(graph, start, goal)
        bfs_time = time.time() - t1

        t2 = time.time()
        dfs_path = dfs(graph, start, goal)
        dfs_time = time.time() - t2

        st.markdown("### 📍 Results")

        st.success(f"BFS Path: {' → '.join(bfs_path)}")
        st.info(f"DFS Path: {' → '.join(dfs_path)}")

        # 📊 Table comparison
        df = pd.DataFrame({
            "Algorithm": ["BFS", "DFS"],
            "Path Length": [len(bfs_path), len(dfs_path)],
            "Execution Time (s)": [bfs_time, dfs_time]
        })

        st.markdown("### 📊 Comparison Table")
        st.dataframe(df)