def dfs(graph, start, goal, path=None, visited=None):
    if visited is None: visited = set()
    if path is None: path = [start]

    if start == goal:
        return path

    visited.add(start)

    for neighbor in graph[start]:
        if neighbor not in visited:
            result = dfs(graph, neighbor, goal, path + [neighbor], visited)
            if result:
                return result
    return None