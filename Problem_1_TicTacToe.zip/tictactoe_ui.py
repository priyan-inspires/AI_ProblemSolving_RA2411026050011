import streamlit as st
import time
from Problem_1_TicTacToe.minimax import best_move_minimax, is_winner, is_full
from Problem_1_TicTacToe.alphabeta import best_move_alphabeta

def run_tictactoe():
    st.subheader("🎮 Tic Tac Toe vs AI")

    if "board" not in st.session_state:
        st.session_state.board = [" "] * 9

    board = st.session_state.board

    cols = st.columns(3)

    for i in range(9):
        if cols[i % 3].button(board[i] if board[i] != " " else "⬜", key=i):
            if board[i] == " ":
                board[i] = "❌"

                if not is_winner(board, "❌") and not is_full(board):

                    t1 = time.time()
                    best_move_minimax(board.copy())
                    t_minimax = time.time() - t1

                    t2 = time.time()
                    move = best_move_alphabeta(board.copy())
                    t_alpha = time.time() - t2

                    board[move] = "⭕"

                    st.success("AI moved!")

                    # 📊 Comparison
                    st.markdown("### ⚡ Algorithm Comparison")
                    st.write(f"Minimax Time: {t_minimax:.6f}s")
                    st.write(f"Alpha-Beta Time: {t_alpha:.6f}s")

    # 🎯 Result
    if is_winner(board, "❌"):
        st.success("🎉 You Win!")
    elif is_winner(board, "⭕"):
        st.error("🤖 AI Wins!")
    elif is_full(board):
        st.info("😐 Draw!")

    if st.button("🔄 Reset Game"):
        st.session_state.board = [" "] * 9