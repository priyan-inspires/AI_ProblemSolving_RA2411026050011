def is_winner(board, player):
    win_states = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ]
    return any(all(board[i] == player for i in combo) for combo in win_states)

def is_full(board):
    return " " not in board

def minimax(board, is_max):
    if is_winner(board, "O"): return 1
    if is_winner(board, "X"): return -1
    if is_full(board): return 0

    if is_max:
        best = -1000
        for i in range(9):
            if board[i] == " ":
                board[i] = "O"
                best = max(best, minimax(board, False))
                board[i] = " "
        return best
    else:
        best = 1000
        for i in range(9):
            if board[i] == " ":
                board[i] = "X"
                best = min(best, minimax(board, True))
                board[i] = " "
        return best

def best_move_minimax(board):
    best_val = -1000
    move = -1
    for i in range(9):
        if board[i] == " ":
            board[i] = "O"
            val = minimax(board, False)
            board[i] = " "
            if val > best_val:
                best_val = val
                move = i
    return move