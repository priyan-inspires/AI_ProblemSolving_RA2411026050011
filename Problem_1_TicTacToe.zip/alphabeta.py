from Problem_1_TicTacToe.minimax import is_winner, is_full

def alphabeta(board, alpha, beta, is_max):
    if is_winner(board, "O"): return 1
    if is_winner(board, "X"): return -1
    if is_full(board): return 0

    if is_max:
        best = -1000
        for i in range(9):
            if board[i] == " ":
                board[i] = "O"
                best = max(best, alphabeta(board, alpha, beta, False))
                board[i] = " "
                alpha = max(alpha, best)
                if beta <= alpha:
                    break
        return best
    else:
        best = 1000
        for i in range(9):
            if board[i] == " ":
                board[i] = "X"
                best = min(best, alphabeta(board, alpha, beta, True))
                board[i] = " "
                beta = min(beta, best)
                if beta <= alpha:
                    break
        return best

def best_move_alphabeta(board):
    best_val = -1000
    move = -1
    for i in range(9):
        if board[i] == " ":
            board[i] = "O"
            val = alphabeta(board, -1000, 1000, False)
            board[i] = " "
            if val > best_val:
                best_val = val
                move = i
    return move